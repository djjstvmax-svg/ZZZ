# Meble Korzeniowski – V25 / Pages CMS

Wersja przygotowana z otrzymanego V22. Poprawiono starszą numerację w danych nawigacji, zachowano logo i kolorystykę oraz 73 zdjęcia w trzech galeriach. Usunięto również numerację etapów procesu na stronie głównej i podstronach. Licznik zdjęć w galerii pozostaje celowo.

## 1. GitHub
1. Utwórz nowe prywatne repozytorium `meble-korzeniowski` (bez dodatkowego README).
2. Rozpakuj ZIP. Wgraj wszystkie pliki i foldery, także ukryty plik `.pages.yml`, do głównego katalogu repozytorium, nie do dodatkowego podfolderu. W razie potrzeby użyj GitHub Desktop lub Git. Nie wgrywaj samego archiwum ZIP.
3. Zatwierdź zmiany (commit) na gałęzi `main`.

## 2. Cloudflare Pages
1. Otwórz https://dash.cloudflare.com/ i wybierz Workers & Pages, następnie utworzenie projektu **Pages** z repozytorium Git (nie nowego Workera).
2. Połącz konto GitHub i wybierz repozytorium. Gałąź produkcyjna: `main`.
3. Framework preset: None. Build command: `python3 build.py`. Build output directory: `dist`. Root directory: pozostaw puste. Zapisz i wdroż.
4. Otwórz przydzielony adres `pages.dev`. Sprawdź galerie, menu, widok mobilny i aktualności.
5. W projekcie Pages wybierz Custom domains i dodaj własną domenę, wykonując instrukcje DNS Cloudflare. Nie zmieniaj konfiguracji dotychczasowego Workera Facebooka.

## 3. Pages CMS
1. Otwórz https://app.pagescms.org/ i zaloguj się przez GitHub.
2. Zezwól aplikacji na dostęp do repozytorium strony (tylko tego repozytorium, jeśli masz taki wybór).
3. Wybierz repozytorium i gałąź `main`. Konfiguracja `.pages.yml` jest już przygotowana.
4. Z menu wybierz np. **Wygląd i układ**, **Strona główna**, **Kuchnie** albo **Kontakt i profile**. Po edycji zapisz. Cloudflare zbuduje stronę po zatwierdzeniu zmian w GitHubie.

## Edycja
- Galerie: dodaj zdjęcie, opis alternatywny, opcjonalny podpis. Lista pozwala zmieniać kolejność. Usunięcie wpisu nie usuwa automatycznie pliku z biblioteki.
- Zdjęcie główne, logo, ilustracje podstron: wybierz lub prześlij plik. W razie potrzeby zmień opis alternatywny. Opis „Wizualizacja inspiracyjna” pozostaje stały w pierwotnych miejscach; zmiana na zdjęcie realizacji wymaga aktualizacji tego oznaczenia w szablonie.
- Wygląd: kolory w formacie #RRGGBB, czcionki, rozmiary, kolumny galerii na komputerze, kolejność/widoczność pięciu sekcji po bloku głównym. Mobilny układ jest responsywny. To panel ustawień, nie edytor dowolnego układu.
- Kontakt: numer, e-mail, adres i linki profili. Wbudowaną mapę Google należy przy przeprowadzce zmienić również w szablonie `templates/kontakt.html` (adres osadzenia mapy).
- Aktualności: zachowano dotychczasowy adres Workera. Token Facebooka pozostaje po stronie Workera, nie w repozytorium.

## Lokalna kontrola
Python 3 (bez zewnętrznych bibliotek): `python3 build.py`, potem `python3 -m http.server 8000 --directory dist` i otwórz http://localhost:8000/. Wygenerowany katalog `dist` nie jest źródłem edycji.

Wdrożenie, autoryzacja Pages CMS i test komunikacji z Facebookiem na docelowej domenie wymagają kont właściciela; nie zostały wykonane w ramach tej paczki.
