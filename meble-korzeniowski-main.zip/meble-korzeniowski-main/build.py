"""Build static Meble Korzeniowski website from editable CMS files; no dependencies."""
from pathlib import Path
import json, re, shutil
from html import escape
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'dist'
T=ROOT/'templates'
def read(p):return p.read_text(encoding='utf-8')
def load(p):return json.loads(read(p))
D={p.stem:load(p) for p in (ROOT/'content').glob('*.json')}
A=D['appearance']; C=D['contact']; titles=load(T/'titles.json')
G=['kuchnie','szafy-i-garderoby','rtv-i-inne']
S=['realizacje','o-nas','proces','aktualnosci','connect']
def esc(v):return escape(str(v or ''),quote=True)
def media(v):
 p=Path(str(v).lstrip('/'))
 if not str(v).startswith('/media/') or '..' in p.parts or not (ROOT/p).is_file():raise ValueError('Nie znaleziono zdjęcia: '+str(v))
 return '/'+p.as_posix()
def https(v):
 if urlsplit(str(v)).scheme!='https' or not urlsplit(str(v)).netloc:raise ValueError('Link musi zaczynać się od https://')
 return v
def num(k,lo,hi):return max(lo,min(hi,int(A[k])))
def color(k):
 v=A[k]
 if not re.fullmatch(r'#[a-fA-F0-9]{6}',v):raise ValueError('Nieprawidłowy kolor '+k)
 return v
def font(k):
 v=A[k]
 if v not in ['Arial','Georgia','Verdana','Tahoma','Trebuchet MS','Times New Roman']:raise ValueError('Nieobsługiwana czcionka')
 return '"'+v+'",'+('serif' if v in ['Georgia','Times New Roman'] else 'sans-serif')
def photos(k):return D[k].get('photos') or []
def gallery(k):
 out=[]
 for i,p in enumerate(photos(k)):
  path=esc(media(p['image']));alt=esc(p.get('alt') or f'{titles[k].split(" | ")[0]} — realizacja {i+1}');caption=esc(p.get('caption',''))
  out.append(f'<figure class="photo-figure"><button aria-label="Powiększ zdjęcie" class="photo-button" data-caption="{caption}" data-photo="{path}"><div class="art"><img alt="{alt}" decoding="async" loading="lazy" src="{path}"/></div></button>'+ (f'<figcaption>{caption}</figcaption>' if caption else '')+'</figure>')
 return ''.join(out) or '<p class="empty">Wkrótce pojawią się nowe realizacje.</p>'
order=[]; seen=set()
for item in A.get('sections',[]):
 k=item.get('section')
 if k in S and k not in seen:
  seen.add(k)
  if item.get('visible',True):order.append(k)
sections=''.join(read(T/f'section-{k}.html') for k in order)
phone=''.join(c for c in C['phone'] if c.isdigit() or c=='+')
def replace(m):
 token=m[1]
 if token=='phonehref':return esc(phone)
 kind,key=token.split(':',1)
 if kind=='gallery':return gallery(key)
 if kind=='cover':return esc(media(photos(key)[0]['image'] if photos(key) else D['home']['image_0']))
 if kind=='count':
  n=len(photos(key));return f'{n} '+('zdjęcie' if n==1 else 'zdjęcia' if n%10 in [2,3,4] and n%100 not in [12,13,14] else 'zdjęć')
 val=D[kind][key]
 if key.startswith('image_') or key=='logo':val=media(val)
 if kind=='contact' and key in ['facebook','google']:val=https(val)
 return esc(val)
pages={}
for k,title in titles.items():
 body=read(T/f'{k}.html').replace('@@sections@@',sections)
 body=re.sub(r'@@([^@]+)@@',replace,body)
 # Remove home links to hidden sections (leave gallery routes intact).
 for anchor in ['realizacje','aktualnosci']:
  if anchor not in order:body=re.sub(r'<a\b[^>]*href="#home/'+anchor+r'"[^>]*>.*?</a>','',body,flags=re.S)
 pages[k]={'title':title,'body':body}
logo=num('logo_size',40,100); word=num('wordmark_size',16,32); label=num('section_label_size',11,22); strip=num('strip_size',10,20)
css=':root{'+''.join(f'--{v}:{color(k)}!important;' for k,v in [('bg','bg'),('fg','fg'),('accent','accent'),('violet','violet'),('violet_deep','violet-deep')])+f'--heading:{font("heading_font")}!important;--body:{font("body_font")}!important;--text:{num("text_size",12,24)}px!important;--scale:{num("heading_scale",75,130)/100}!important;--cols:{num("columns",2,5)}!important;'+'}'
css+=f'.header .brand strong,.header .brand small{{color:{color("wordmark")}}}.header .brand .brand-logo{{width:{logo}px;height:{logo}px;max-height:{logo}px;flex-basis:{logo}px}}.header .brand strong{{font-size:{word}px}}.header .brand small{{font-size:{max(10,word-8)}px}}.section-label.eyebrow{{font-size:{label}px}}.strip{{font-size:{strip}px}}'
css+=f'@media(min-width:781px) and (max-width:1120px){{.header .brand strong{{font-size:{max(14,word-3)}px}}.header .brand small{{font-size:{max(10,word-10)}px}}}}@media(max-width:780px){{.header .brand .brand-logo{{width:{max(32,logo-12)}px;height:{max(32,logo-12)}px;max-height:{max(32,logo-12)}px;flex-basis:{max(32,logo-12)}px}}.header .brand strong{{font-size:{max(14,word-2)}px}}.header .brand small{{font-size:{max(10,word-9)}px}}.section-label.eyebrow{{font-size:{max(10,label-1)}px}}.strip{{font-size:{max(9,strip-1)}px}}.hero h1{{font-size:calc(clamp(39px,8vw,57px)*var(--scale))}}}}@media(max-width:420px){{.hero h1{{font-size:calc(43px*var(--scale))}}}}@media(max-width:360px){{.header .brand strong{{font-size:{max(14,word-4)}px}}.header .brand small{{font-size:{max(10,word-10)}px}}}}'
head=read(T/'head.html').replace('</head>','<style>'+css+'</style></head>')
runtime=read(T/'runtime.js').replace('let i=0;const show=n=>','if(!buttons.length)continue;let i=0;const show=n=>')
js='const pages = '+json.dumps(pages,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+runtime
if OUT.exists():shutil.rmtree(OUT)
OUT.mkdir();shutil.copytree(ROOT/'media',OUT/'media')
(OUT/'index.html').write_text('<!DOCTYPE html><html lang="pl">'+head+'<body>'+pages['home']['body']+'<script src="site.js"></script></body></html>',encoding='utf-8')
(OUT/'site.js').write_text(js,encoding='utf-8')
print('Gotowe:',len(pages),'widoków,',sum(map(lambda k:len(photos(k)),G)),'zdjęć realizacji.')
