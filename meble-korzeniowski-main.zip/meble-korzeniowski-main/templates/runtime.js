;
const portfolioChoices={};
for(const key of ['kuchnie','szafy-i-garderoby','rtv-i-inne']){
 const doc=new DOMParser().parseFromString(pages[key].body,'text/html');
 const photos=[...doc.querySelectorAll('[data-photo]')];if(!photos.length)continue;
 let prev=-1;try{const v=sessionStorage.getItem('portfolio-v15-'+key);if(v!==null)prev=Number(v)}catch{};
 const options=photos.map((_,i)=>i).filter(i=>photos.length===1||i!==prev);
 const i=options[Math.floor(Math.random()*options.length)];
 try{sessionStorage.setItem('portfolio-v15-'+key,String(i))}catch{};
 portfolioChoices[key]={src:photos[i].dataset.photo,alt:photos[i].querySelector('img')?.alt||'Zdjęcie realizacji'};
}

function render(){const [key,anchor]=location.hash.slice(1).split('/');const page=pages[key==='o-firmie'?'o-nas':key]||pages.home;document.body.innerHTML=page.body;document.title=page.title;init();if(anchor){document.getElementById(anchor)?.scrollIntoView()}else{window.scrollTo(0,0)}}
function init(){const toggle=document.querySelector('.menu-toggle'),nav=document.querySelector('.nav');if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open))});nav.addEventListener('click',e=>{if(e.target.closest('a')){nav.classList.remove('open');toggle.setAttribute('aria-expanded','false')}})}
for(const dialog of document.querySelectorAll('.lightbox')){const buttons=[...dialog.closest('.page').querySelectorAll('[data-photo]')];let i=0;const show=n=>{i=(n+buttons.length)%buttons.length;const b=buttons[i],im=dialog.querySelector('img');im.src=b.dataset.photo;im.alt=b.querySelector('img')?.alt||'Zdjęcie realizacji';dialog.querySelector('.lightbox-caption').textContent=`${i+1} / ${buttons.length}${b.dataset.caption ? " — "+b.dataset.caption : ""}`};buttons.forEach((b,n)=>b.addEventListener('click',()=>{show(n);dialog.showModal()}));dialog.querySelector('[data-close]').onclick=()=>dialog.close();dialog.querySelector('[data-prev]').onclick=()=>show(i-1);dialog.querySelector('[data-next]').onclick=()=>show(i+1);dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});dialog.addEventListener('keydown',e=>{if(e.key==='ArrowRight')show(i+1);if(e.key==='ArrowLeft')show(i-1)})}
for(const b of document.querySelectorAll('.embed-load:not(.news-load)')){b.onclick=()=>{const frame=document.createElement('iframe');frame.src=b.dataset.embed;frame.title=b.dataset.kind==='fb'?'Aktualności na Facebooku':'Google Maps — lokalizacja firmy';frame.height=b.dataset.kind==='fb'?'540':'400';frame.loading='lazy';frame.referrerPolicy='strict-origin-when-cross-origin';frame.allowFullscreen=true;b.parentElement.replaceChildren(frame)}}

// Portfolio: sample once per page load, independently of Facebook.
for (const card of document.querySelectorAll('.news-portfolio .news-card')) {
 const key=card.getAttribute('href').slice(1), img=card.querySelector('img');
 if(!img || !portfolioChoices[key]) continue;
 const selected=portfolioChoices[key]; img.src=selected.src; img.alt=selected.alt;
}
// Live Facebook posts through the Cloudflare Worker. No access token in the browser.
const host=document.getElementById('fb-timeline');
if(host){
 const endpoint='https://weathered-poetry-70f2.djjstvmax-872.workers.dev/';
 host.setAttribute('aria-busy','true');
 const status=document.createElement('p');status.className='news-status';status.setAttribute('role','status');status.textContent='Pobieramy najnowsze aktualności…';
 host.replaceChildren(status);
 const safeUrl=(value,facebookOnly=false)=>{try{const u=new URL(value);if(u.protocol!=='https:')return null;if(facebookOnly && !(/(^|\.)facebook\.com$/i.test(u.hostname)))return null;return u.href}catch{return null}};
 const dateFormat=new Intl.DateTimeFormat('pl-PL',{day:'numeric',month:'long',year:'numeric',timeZone:'Europe/Warsaw'});
 const makeCard=post=>{
  const card=document.createElement('article');card.className='news-card fb-post';
  const link=safeUrl(post.permalink_url,true),picture=safeUrl(post.full_picture);
  if(picture){const img=document.createElement('img');img.src=picture;img.alt='Zdjęcie z publikacji Korzeniowski Meble';img.loading='lazy';img.decoding='async';img.addEventListener('error',()=>img.remove(),{once:true});card.append(img)}
  const date=new Date(post.created_time);if(Number.isFinite(date.getTime())){const t=document.createElement('time');t.dateTime=date.toISOString();t.textContent=dateFormat.format(date);card.append(t)}
  const message=typeof post.message==='string'?post.message.trim():'';
  const text=document.createElement('p');text.className='fb-message';text.textContent=message||'Zobacz najnowszą realizację na Facebooku.';card.append(text);
  if(message.length>230){text.classList.add('fb-clamped');const more=document.createElement('button');more.type='button';more.className='fb-expand';more.textContent='Czytaj więcej';more.setAttribute('aria-expanded','false');more.onclick=()=>{const expanded=text.classList.toggle('fb-clamped')===false;more.textContent=expanded?'Zwiń':'Czytaj więcej';more.setAttribute('aria-expanded',String(expanded))};card.append(more)}
  if(link){const a=document.createElement('a');a.className='arrow-link';a.href=link;a.target='_blank';a.rel='noopener noreferrer';a.textContent='Zobacz na Facebooku ↗';card.append(a)}return card;
 };
 const load=async()=>{
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12000);
  try{
   const response=await fetch(endpoint,{signal:controller.signal,cache:'no-store',credentials:'omit'});if(!response.ok)throw new Error('HTTP '+response.status);
   const result=await response.json();if(!Array.isArray(result.data)||result.error)throw new Error('Nieprawidłowa odpowiedź');if(!host.isConnected)return;
   const posts=result.data.filter(p=>p&&typeof p==='object').sort((a,b)=>(Date.parse(b.created_time)||0)-(Date.parse(a.created_time)||0)).slice(0,10);
   if(!posts.length){status.textContent='Brak aktualności do wyświetlenia.';return}
   const grid=document.createElement('div');grid.className='news-posts fb-posts';let shown=0;
   const append=()=>{const until=Math.min(shown+4,posts.length);for(;shown<until;shown++)grid.append(makeCard(posts[shown]));button.hidden=shown>=posts.length;};
   const button=document.createElement('button');button.type='button';button.className='fb-expand fb-more';button.textContent='Pokaż więcej aktualności';button.onclick=append;
   host.replaceChildren(grid,button);append();
  }catch(e){if(!host.isConnected)return;status.textContent='Nie udało się teraz pobrać aktualności. Spróbuj ponownie lub przejdź na Facebooka.';const retry=document.createElement('button');retry.type='button';retry.className='fb-expand';retry.textContent='Spróbuj ponownie';retry.onclick=()=>{status.textContent='Pobieramy najnowsze aktualności…';host.replaceChildren(status);host.setAttribute('aria-busy','true');load()};host.replaceChildren(status,retry)}finally{clearTimeout(timer);host.setAttribute('aria-busy','false')}
 };load();
}

}
window.addEventListener('hashchange',render);render();